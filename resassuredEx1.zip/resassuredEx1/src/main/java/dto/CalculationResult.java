
package dto;


public class CalculationResult {
   public String operation;  
   public int result;

  public CalculationResult(String operation, int result) {
    this.operation = operation;
    this.result = result;
  }
   
}
